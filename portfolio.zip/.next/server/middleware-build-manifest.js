globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/65fbe02f49b22b6c.js",
    "static/chunks/72a7109cf212cd02.js",
    "static/chunks/6740f161f60c6ab5.js",
    "static/chunks/a4eeb46e07741350.js",
    "static/chunks/0ff0e53d3302b2ff.js",
    "static/chunks/turbopack-d4e2e63c1886787c.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];